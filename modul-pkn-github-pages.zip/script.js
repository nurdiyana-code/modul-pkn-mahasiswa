
function checkAnswer(correct){

let result=document.getElementById("result")

if(correct){
result.innerHTML="Jawaban benar!"
result.style.color="green"
}else{
result.innerHTML="Jawaban salah. Coba lagi."
result.style.color="red"
}

}
